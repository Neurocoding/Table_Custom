import tableHandlers from './tableHandlers.js';
import handleKeyboardNavigation from './keyboardNavigation.js';
import createInitialRow from './initialRow.js';
import {
    attachInputListeners,
    calculateAndUpdate,
    handleFocus,
    handleBlur,
    validateInput,
    resetToLastValid,
    formatAndDisplay
} from './cellInteractions.js';

// Exporting table interactions as a single default object
export default {
    ...tableHandlers,
    handleKeyboardNavigation,
    createInitialRow,
    attachInputListeners,
    calculateAndUpdate,
    handleFocus,
    handleBlur,
    validateInput,
    resetToLastValid,
    formatAndDisplay
};
