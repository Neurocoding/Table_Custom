// setupEventListeners.js
export default function setupEventListeners() {
    const templateContent = document.getElementById('TemplateContent');
    console.log('Template Content initialized:', templateContent);

    templateContent.addEventListener('click', (event) => {
        const target = event.target;
        console.log('Click event on:', target.id);

        if (target.id === 'addRowButton' || target.id === 'removeRowButton') {
            // Assuming the handlers for these are imported here if needed
            console.log(`${target.id} was clicked`);
            // execute corresponding handler
        }
    });

    document.addEventListener('keydown', (event) => {
        console.log('Key pressed:', event.key);
        // handle keyboard events
    });
}
