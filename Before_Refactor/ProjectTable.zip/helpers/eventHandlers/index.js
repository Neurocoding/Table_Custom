// Index file to export all event handlers
import setupEventListeners from './setupEventListeners.js';
import setupMutationObserver from './mutationObserverSetup.js';

export default {
    setupEventListeners,
    setupMutationObserver
};
