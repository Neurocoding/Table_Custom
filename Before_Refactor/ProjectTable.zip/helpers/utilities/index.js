// Importing utility functions
import domUtils from './domUtils.js';
import formatCurrencyDK from './FormatCurrencyDK.js';

// Exporting utilities as a default object
export default {
    ...domUtils,
    formatCurrencyDK
};
